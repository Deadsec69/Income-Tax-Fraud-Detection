import pandas as pd
import numpy as np
from sklearn.svm import OneClassSVM
import pickle


#print(mypath)

df=pd.read_csv("exc.csv")
tf=df.copy()

filename = 'finalized_mod.sav'
loaded_model = pickle.load(open(filename, 'rb'))
def predic():
    k=[]
    del tf["uid"]
    y=loaded_model.predict(tf)
    tf["uid"]=pd.Series(df["uid"])
    for i in range(len(y)):
        if y[i]==-1:
            k.append(int(df["uid"][i]))
    return k
