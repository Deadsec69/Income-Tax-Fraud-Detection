from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import pandas as pd
from fraud import ml
# Create your views here.
from django.http import StreamingHttpResponse
import requests
import json

url = "http://192.168.43.250:3003/ml"
url2="http://192.168.43.250:3002/fraud"
url3="http://192.168.43.250:3003/blockchain"

def month(request):
    my_dict=requests.get(url).json()
    train = pd.DataFrame.from_dict(my_dict, orient='index')
    train.to_csv("ex_bank13.csv")
    return JsonResponse(my_dict,safe=False)

def index(request):
    my_dict=requests.get(url2).json()
    #print(my_dict)
    s=dict(my_dict)
    return render(request,'index.html',s)


def block(request):
    my_dict=requests.get(url3).json()
    return JsonResponse(my_dict,safe=False)


def for_app(request):
    y=ml.predic()
    return JsonResponse(y,safe=False)
