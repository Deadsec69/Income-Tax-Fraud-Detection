from django.apps import AppConfig


class FraudConfig(AppConfig):
    name = 'fraud'
