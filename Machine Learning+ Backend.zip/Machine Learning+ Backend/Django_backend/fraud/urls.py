from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from fraud import views
app_name='fraud'
urlpatterns = [
    url(r'^$',views.for_app,name='for_app'),
    url(r'^months/',views.month,name='month'),
    url(r'^chain/',views.block,name='chain'),
    ]
