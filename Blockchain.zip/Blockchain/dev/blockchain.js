const sha256 = require('sha256');
const currentNodeUrl = process.argv[3];
const uuid = require('uuid/v1');

function Blockchain() {
	this.chain = [];
	this.pendingTransactions = [{
    "amount": 38.66,
    "recipient": 223243000000,
    "sender": 561715000000,
    "transactionId": "yMxlGqvoVfXr3Sshf7LhjouCombsgKVD"
  },
  {
    "amount": 50,
    "recipient": 326665000000,
    "sender": 563129000000,
    "transactionId": "6F09uTwy4llmZZWhJOjV2mbRvgk600Ht"
  },
  {
    "amount": 181,
    "recipient": 326665000000,
    "sender": 256533000000,
    "transactionId": "vJ3CFWENkOtpYCyx4BfjlrjjUSBBRRme"
  },
  {
    "amount": 671.64,
    "recipient": 787612000000,
    "sender": 829473000000,
    "transactionId": "mOdjBcbLhsUmjNXYNZpuwHshwFKXwUmc"
  },
  {
    "amount": 1065.41,
    "recipient": 991959000000,
    "sender": 278515000000,
    "transactionId": "5RLwUKLSPKQ1iswEy8fuAQaBz9taaZZp"
  },
  {
    "amount": 1157.86,
    "recipient": 787612000000,
    "sender": 561877000000,
    "transactionId": "TiBo9p5DUuao57iLpykgC7FVDt2fJTl6"
  },
  {
    "amount": 1373.43,
    "recipient": 991671000000,
    "sender": 221345000000,
    "transactionId": "tcjnol0vwmkgweIcQJApYZJJ8buxyOaM"
  },
  {
    "amount": 1563.82,
    "recipient": 787612000000,
    "sender": 551731000000,
    "transactionId": "jScZBoziKwofnMp3AWis6cGQqsHQOhas"
  },
  {
    "amount": 1614.64,
    "recipient": 789913000000,
    "sender": 781792000000,
    "transactionId": "uhN5WXLJTRks8WUYP8ugC5ksz14n4vQV"
  },
  {
    "amount": 1684.81,
    "recipient": 551731000000,
    "sender": 121569000000,
    "transactionId": "401dP7GmhlzUd4cdwRQoABsXMaLkVqjq"
  },
  {
    "amount": 2204.04,
    "recipient": 781616000000,
    "sender": 789490000000,
    "transactionId": "WXzhpnyjfqRPBEOjev1I0llYSi3hs2qT"
  },
  {
    "amount": 2252.44,
    "recipient": 223243000000,
    "sender": 651507000000,
    "transactionId": "SnHxp13CLAkLczAQo7Cejh8nGf4petWi"
  },
  {
    "amount": 2560.74,
    "recipient": 951900000000,
    "sender": 599729000000,
    "transactionId": "IvZCgGWsEenB4bYbZplOtXCY1Vafwbuc"
  },
  {
    "amount": 2641.47,
    "recipient": 781616000000,
    "sender": 451653000000,
    "transactionId": "GAxLXi0hOzdZhMEmJLhWR8r40YZiGctz"
  },
  {
    "amount": 2791.42,
    "recipient": 787923000000,
    "sender": 123108000000,
    "transactionId": "r5WjZOV9oSMT6WrW6BItsK3Q7aheERYD"
  },
  {
    "amount": 2970.97,
    "recipient": 789913000000,
    "sender": 231153000000,
    "transactionId": "jLhvJRsyglMqmZ9qkEENKPvEG2PR9BQO"
  },
  {
    "amount": 3099.97,
    "recipient": 951900000000,
    "sender": 392097000000,
    "transactionId": "nZRb5J5azwBQ4w0aTqJIVsDSDA7RYGGX"
  },
  {
    "amount": 3295.19,
    "recipient": 787923000000,
    "sender": 441384000000,
    "transactionId": "2xJEmeV65EEqTwdmIn0pBNLMcSpVasPs"
  },
  {
    "amount": 3448.92,
    "recipient": 321632000000,
    "sender": 353335000000,
    "transactionId": "gUdaZMMVkzmGiTM4GlUn6HrB1JF2eteJ"
  },
  {
    "amount": 3876.41,
    "recipient": 991959000000,
    "sender": 222405000000,
    "transactionId": "9WPkv58waIfaKP6LEm9pX4sG32H9b1uJ"
  },
  {
    "amount": 4024.36,
    "recipient": 691913000000,
    "sender": 951177000000,
    "transactionId": "DyHZ1cGn5JxMd7scW3EOpfhLa6ojCCmh"
  },
  {
    "amount": 4098.78,
    "recipient": 891717000000,
    "sender": 891635000000,
    "transactionId": "c16ubiscpmtmYW7ub1b0ryAfhVGEJkXa"
  },
  {
    "amount": 4206.84,
    "recipient": 362044000000,
    "sender": 781757000000,
    "transactionId": "zd62V2lvWyTjIJtMmZUejZZJPyxi2RrT"
  },
  {
    "amount": 4510.22,
    "recipient": 789867000000,
    "sender": 541255000000,
    "transactionId": "8OLVw9afLtgHzRWZiaufB21RPH6iIb7B"
  },
  {
    "amount": 5031.22,
    "recipient": 225247000000,
    "sender": 378151000000,
    "transactionId": "NWosbSxMnXlC8XdPb05VpIQphSgCZBb7"
  },
  {
    "amount": 5086.48,
    "recipient": 999260000000,
    "sender": 121593000000,
    "transactionId": "mTMV5MkEIQPAo98ou01RJEI9LLVr5A0o"
  },
  {
    "amount": 5281.48,
    "recipient": 999260000000,
    "sender": 121849000000,
    "transactionId": "OBa6uNqQ9bISD97khw2d5VAFp6ixlvIl"
  },
  {
    "amount": 5307.88,
    "recipient": 362044000000,
    "sender": 280972000000,
    "transactionId": "QWJiCJfzcLHHSyipliH38uZ3YbbLoFJR"
  },
  {
    "amount": 5337.77,
    "recipient": 691913000000,
    "sender": 255196000000,
    "transactionId": "6uQmEuV3kxxJ8TkvnCqX00v4XrDFyODR"
  },
  {
    "amount": 5346.89,
    "recipient": 944484000000,
    "sender": 782249000000,
    "transactionId": "pP1vEQkbZNUZxRKa8meRT8L1eySzd3pX"
  },
  {
    "amount": 5529.13,
    "recipient": 789867000000,
    "sender": 525242000000,
    "transactionId": "wWaKYmthlxnwqSmtxloaDjLUhpyBLY3b"
  },
  {
    "amount": 5758.59,
    "recipient": 551731000000,
    "sender": 781298000000,
    "transactionId": "DfECWi23hZnMDbvCBDOZlFWCV8HUoIaB"
  },
  {
    "amount": 5885.56,
    "recipient": 362044000000,
    "sender": 791804000000,
    "transactionId": "4LutbePvdi7RRVIEWOrsGYYy8gi9lAfl"
  },
  {
    "amount": 6061.13,
    "recipient": 881043000000,
    "sender": 991558000000,
    "transactionId": "SxuLNaINUWslHnKBi7unUr06V2Vw2e7f"
  },
  {
    "amount": 7107.77,
    "recipient": 782049000000,
    "sender": 569408000000,
    "transactionId": "VWr8nmy3m4npDMFsbx2ruSzX0xmtttLL"
  },
  {
    "amount": 7413.54,
    "recipient": 787923000000,
    "sender": 791427000000,
    "transactionId": "tyZZbowyLHDVEEf3nNZ1Qe7hz7IfI7mK"
  },
  {
    "amount": 7817.71,
    "recipient": 782049000000,
    "sender": 259573000000,
    "transactionId": "fUCmQief7MT5sbP5PP493AnRjn1NuNrW"
  },
  {
    "amount": 7823.46,
    "recipient": 999260000000,
    "sender": 232268000000,
    "transactionId": "AJjlsmMBTatD0TMiSxMmppdH8PSvpzev"
  },
  {
    "amount": 7861.64,
    "recipient": 691913000000,
    "sender": 233633000000,
    "transactionId": "Bxffx0zxFRdzjH3PPhB4cpVOI5kqwBLH"
  },
  {
    "amount": 8009.09,
    "recipient": 881043000000,
    "sender": 255295000000,
    "transactionId": "Sf6kgTSriOEA4Nf72FEI1IhZSIvvbxvB"
  },
  {
    "amount": 8603.42,
    "recipient": 225247000000,
    "sender": 121616000000,
    "transactionId": "vtop0EilxfSHNcjG9uYdb8CKDcePBwyq"
  },
  {
    "amount": 8901.99,
    "recipient": 321632000000,
    "sender": 238833000000,
    "transactionId": "wR0wqTDCnDLo2f1KXBiN5BDFCJQR3EtA"
  },
  {
    "amount": 9164.71,
    "recipient": 789913000000,
    "sender": 891659000000,
    "transactionId": "rfzDaT0CgVLa6s6K2QhFkboJ3P08beQq"
  },
  {
    "amount": 9302.79,
    "recipient": 991671000000,
    "sender": 221974000000,
    "transactionId": "SDtbKfkXD5w4Q7LcoIBEyhS1UvyWTaol"
  },
  {
    "amount": 9478.39,
    "recipient": 881043000000,
    "sender": 423558000000,
    "transactionId": "oHLZoVlWLjIFmpAm1jgNxyxZduY190FS"
  },
  {
    "amount": 9644.94,
    "recipient": 951900000000,
    "sender": 563998000000,
    "transactionId": "0DQXDxmOivHzKHEkCvFUmA7irVYJCvUR"
  },
  {
    "amount": 9920.52,
    "recipient": 321632000000,
    "sender": 221940000000,
    "transactionId": "eGcK0qSIoz7KdcZWQ1p9hb4lVf6KXSeQ"
  },
  {
    "amount": 11633.76,
    "recipient": 891717000000,
    "sender": 326802000000,
    "transactionId": "kov0sHXa8crSbh3LOmJZFUcwh4w0yFpx"
  },
  {
    "amount": 11668.14,
    "recipient": 782049000000,
    "sender": 326665000000,
    "transactionId": "ebw4L0gN2UfC4JHMU2p84EOevUgUsV22"
  },
  {
    "amount": 13875.98,
    "recipient": 944484000000,
    "sender": 882008000000,
    "transactionId": "Of8Q9sk6s1bFM3IfdPwM1DpvhxnFAyfB"
  },
  {
    "amount": 23261.3,
    "recipient": 781616000000,
    "sender": 452001000000,
    "transactionId": "cYmktozR5yaUW21p2yubAbjT3T6E6crl"
  },
  {
    "amount": 24213.67,
    "recipient": 225247000000,
    "sender": 245671000000,
    "transactionId": "1qAKjeqWPQDxSBJI4ccUwdmiqItmCG0c"
  },
  {
    "amount": 56953.9,
    "recipient": 944484000000,
    "sender": 882824000000,
    "transactionId": "mTA6SEpIvJj4r61ETlgAS5mFHMR3NlCz"
  },
  {
    "amount": 62610.8,
    "recipient": 223243000000,
    "sender": 231938000000,
    "transactionId": "sIPrCTEvndz2y6eeBdcNFIM6EatnyTg3"
  },
  {
    "amount": 82940.31,
    "recipient": 789867000000,
    "sender": 896477000000,
    "transactionId": "wDU5IjBlGqQ8m5TNUwmLl2AAROx4x439"
  },
  {
    "amount": 110414.71,
    "recipient": 551731000000,
    "sender": 521510000000,
    "transactionId": "smpRtGchnhdCe43OkukO4hLaWno0xcqu"
  },
  {
    "amount": 186422.28,
    "recipient": 326665000000,
    "sender": 362044000000,
    "transactionId": "AqF6zf3G0w7x6yrpj30daiHC6s5VWh4J"
  },
  {
    "amount": 215310.3,
    "recipient": 991671000000,
    "sender": 251100000000,
    "transactionId": "t4YoTcXuZO7DLKMfyCNBWEvZ0nASEdzu"
  },
  { 
    "amount": 229133.94,
    "recipient": 891717000000,
    "sender": 222576000000,
    "transactionId": "FjZog4oHiDkznX81V6ypTX5Qm4TURgEq"
  },
  {
    "amount": 311685.89,
    "recipient": 991959000000,
    "sender": 827933000000,
    "transactionId": "Qnpjr92D4i7Wdzotb5NZqH0Z4sGYqKey"
  }];
	this.currentNodeUrl = currentNodeUrl;
	this.networkNodes = [];
	this.createNewBlock(100, '0', '0');
};


Blockchain.prototype.createNewBlock = function(nonce, previousBlockHash, hash) {
	const newBlock = {
		index: this.chain.length + 1,
		timestamp: Date.now(),
		transactions: this.pendingTransactions,
		nonce: nonce,
		hash: hash,
		previousBlockHash: previousBlockHash
	};

	this.pendingTransactions = [];
	this.chain.push(newBlock);

	return newBlock;
};



Blockchain.prototype.getLastBlock = function() {
	return this.chain[this.chain.length - 1];
};


Blockchain.prototype.createNewTransaction = function(amount, sender, recipient) {
	const newTransaction = {
		amount: amount,
		sender: sender,
		recipient: recipient,
		transactionId: uuid().split('-').join('')
	};

	return newTransaction;
};


Blockchain.prototype.addTransactionToPendingTransactions = function(transactionObj) {
	
	this.pendingTransactions.push(transactionObj);
	return this.getLastBlock()['index'] + 1;
};


Blockchain.prototype.hashBlock = function(previousBlockHash, currentBlockData, nonce) {
	const dataAsString = previousBlockHash + nonce.toString() + JSON.stringify(currentBlockData);
	const hash = sha256(dataAsString);
	return hash;
};


Blockchain.prototype.proofOfWork = function(previousBlockHash, currentBlockData) {
	let nonce = 0;
	let hash = this.hashBlock(previousBlockHash, currentBlockData, nonce);
	while (hash.substring(0, 4) !== '0000') {
		nonce++;
		hash = this.hashBlock(previousBlockHash, currentBlockData, nonce);
	}
	return nonce;
};



Blockchain.prototype.chainIsValid = function(blockchain) {
	let validChain = true;

	for (var i = 1; i < blockchain.length; i++) {
		const currentBlock = blockchain[i];
		const prevBlock = blockchain[i - 1];
		const blockHash = this.hashBlock(prevBlock['hash'], { transactions: currentBlock['transactions'], index: currentBlock['index'] }, currentBlock['nonce']);
		if (blockHash.substring(0, 4) !== '0000') validChain = false;
		if (currentBlock['previousBlockHash'] !== prevBlock['hash']) validChain = false;
	};

	const genesisBlock = blockchain[0];
	const correctNonce = genesisBlock['nonce'] === 100;
	const correctPreviousBlockHash = genesisBlock['previousBlockHash'] === '0';
	const correctHash = genesisBlock['hash'] === '0';
	const correctTransactions = genesisBlock['transactions'].length === 0;

	if (!correctNonce || !correctPreviousBlockHash || !correctHash || !correctTransactions) validChain = false;

	return validChain;
};


Blockchain.prototype.getBlock = function(blockHash) {
	let correctBlock = null;
	this.chain.forEach(block => {
		if (block.hash === blockHash) correctBlock = block;
	});
	return correctBlock;
};


Blockchain.prototype.getTransaction = function(transactionId) {
	let correctTransaction = null;
	let correctBlock = null;

	this.chain.forEach(block => {
		block.transactions.forEach(transaction => {
			if (transaction.transactionId === transactionId) {
				correctTransaction = transaction;
				correctBlock = block;
			};
		});
	});

	return {
		transaction: correctTransaction,
		block: correctBlock
	};
};


Blockchain.prototype.getAddressData = function(address) {
	const addressTransactions = [];
	this.chain.forEach(block => {
		block.transactions.forEach(transaction => {
			if(transaction.sender === address || transaction.recipient === address) {
				addressTransactions.push(transaction);
			};
		});
	});

	let balance = 0;
	addressTransactions.forEach(transaction => {
		if (transaction.recipient === address) balance += transaction.amount;
		else if (transaction.sender === address) balance -= transaction.amount;
	});

	return {
		addressTransactions: addressTransactions,
		addressBalance: balance
	};
};






module.exports = Blockchain;














