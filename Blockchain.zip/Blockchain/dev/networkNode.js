const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const Blockchain = require('./blockchain');
const uuid = require('uuid/v1');
const port = process.argv[2];
const rp = require('request-promise');
const fs=require('fs');

const nodeAddress = uuid().split('-').join('');

const bitcoin = new Blockchain();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


// get entire blockchain
app.get('/blockchain', function (req, res) {
  res.send(bitcoin);
});


// create a new transaction
app.post('/transaction', function(req, res) {
	const newTransaction = req.body;
	const blockIndex = bitcoin.addTransactionToPendingTransactions(newTransaction);
	res.json({ note: `Transaction will be added in block ${blockIndex}.` });
});


// broadcast transaction
app.post('/transaction/broadcast', function(req, res) {
	const newTransaction = bitcoin.createNewTransaction(JSON.parse(JSON.stringify(req.body)).amount, JSON.parse(JSON.stringify(req.body)).sender, JSON.parse(JSON.stringify(req.body)).recipient);
	bitcoin.addTransactionToPendingTransactions(newTransaction);
	console.log(`${JSON.parse(JSON.stringify(req.body)).sender}`);
	const requestPromises = [null];
	bitcoin.networkNodes.forEach(networkNodeUrl => {
		const requestOptions = {
			uri: networkNodeUrl + '/transaction',
			method: 'POST',
			body: newTransaction,
			json: true
		};

		requestPromises.push(rp(requestOptions));
	});

	Promise.all(requestPromises)
	.then(data => {
		// if(bitcoin.pendingTransactions.length==3)
		// {	const requestPromises = [null];
		// 	const requestOptions={
		// 		uri: bitcoin.currentNodeUrl+'/mine',
		// 		method: 'GET',
		// 		json :true
		// 	}
		// 	requestPromises.push(rp(requestPromises));
		// Promise.all(requestPromises)
		// .then(data=>{
		// 	res.json({note:'Mined'});
		// });
		// }
		// else
		res.json({ note: 'Transaction created and broadcast successfully.' });
	});
});


// mine a block
app.get('/mine', function(req, res) {
	const lastBlock = bitcoin.getLastBlock();
	const previousBlockHash = lastBlock['hash'];
	const currentBlockData = {
		transactions: bitcoin.pendingTransactions,
		index: lastBlock['index'] + 1
	};
	const nonce = bitcoin.proofOfWork(previousBlockHash, currentBlockData);
	const blockHash = bitcoin.hashBlock(previousBlockHash, currentBlockData, nonce);
	const newBlock = bitcoin.createNewBlock(nonce, previousBlockHash, blockHash);

	const requestPromises = [null];
	bitcoin.networkNodes.forEach(networkNodeUrl => {
		const requestOptions = {
			uri: networkNodeUrl + '/receive-new-block',
			method: 'POST',
			body: { newBlock: newBlock },
			json: true
		};

		requestPromises.push(rp(requestOptions));
	});

	Promise.all(requestPromises)
	.then(data => {
		const requestOptions = {
			uri: bitcoin.currentNodeUrl + '/transaction/broadcast',
			method: 'POST',
			body: {
				amount: 12.5,
				sender: "00",
				recipient: nodeAddress
			},
			json: true
		};

		return rp(requestOptions);
	})
	.then(data => {
		res.json({
			note: "New block mined & broadcast successfully",
			block: newBlock
		});
	});
});


// receive new block
app.post('/receive-new-block', function(req, res) {
	const newBlock = req.body.newBlock;
	const lastBlock = bitcoin.getLastBlock();
	const correctHash = lastBlock.hash === newBlock.previousBlockHash; 
	const correctIndex = lastBlock['index'] + 1 === newBlock['index'];

	if (correctHash && correctIndex) {
		bitcoin.chain.push(newBlock);
		bitcoin.pendingTransactions = [];
		res.json({
			note: 'New block received and accepted.',
			newBlock: newBlock
		});
	} else {
		res.json({
			note: 'New block rejected.',
			newBlock: newBlock
		});
	}
});


// register a node and broadcast it the network
app.post('/register-and-broadcast-node', function(req, res) {
	const newNodeUrl = req.body.newNodeUrl;
	if (bitcoin.networkNodes.indexOf(newNodeUrl) == -1) bitcoin.networkNodes.push(newNodeUrl);

	const regNodesPromises = [null];
	bitcoin.networkNodes.forEach(networkNodeUrl => {
		const requestOptions = {
			uri: networkNodeUrl + '/register-node',
			method: 'POST',
			body: { newNodeUrl: newNodeUrl },
			json: true
		};

		regNodesPromises.push(rp(requestOptions));
	});

	Promise.all(regNodesPromises)
	.then(data => {
		const bulkRegisterOptions = {
			uri: newNodeUrl + '/register-nodes-bulk',
			method: 'POST',
			body: { allNetworkNodes: [ ...bitcoin.networkNodes, bitcoin.currentNodeUrl ] },
			json: true
		};

		return rp(bulkRegisterOptions);
	})
	.then(data => {
		res.json({ note: 'New node registered with network successfully.' });
	});
});


// register a node with the network
app.post('/register-node', function(req, res) {
	const newNodeUrl = req.body.newNodeUrl;
	const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(newNodeUrl) == -1;
	const notCurrentNode = bitcoin.currentNodeUrl !== newNodeUrl;
	if (nodeNotAlreadyPresent && notCurrentNode) bitcoin.networkNodes.push(newNodeUrl);
	res.json({ note: 'New node registered successfully.' });
});


// register multiple nodes at once
app.post('/register-nodes-bulk', function(req, res) {
	const allNetworkNodes = req.body.allNetworkNodes;
	allNetworkNodes.forEach(networkNodeUrl => {
		const nodeNotAlreadyPresent = bitcoin.networkNodes.indexOf(networkNodeUrl) == -1;
		const notCurrentNode = bitcoin.currentNodeUrl !== networkNodeUrl;
		if (nodeNotAlreadyPresent && notCurrentNode) bitcoin.networkNodes.push(networkNodeUrl);
	});

	res.json({ note: 'Bulk registration successful.' });
});


// consensus
app.get('/consensus', function(req, res) {
	const requestPromises = [null];
	bitcoin.networkNodes.forEach(networkNodeUrl => {
		const requestOptions = {
			uri: networkNodeUrl + '/blockchain',
			method: 'GET',
			json: true
		};

		requestPromises.push(rp(requestOptions));
	});

	Promise.all(requestPromises)
	.then(blockchains => {
		const currentChainLength = bitcoin.chain.length;
		let maxChainLength = currentChainLength;
		let newLongestChain = null;
		let newPendingTransactions = null;

		blockchains.forEach(blockchain => {
			if (blockchain.chain.length > maxChainLength) {
				maxChainLength = blockchain.chain.length;
				newLongestChain = blockchain.chain;
				newPendingTransactions = blockchain.pendingTransactions;
			};
		});


		if (!newLongestChain || (newLongestChain && !bitcoin.chainIsValid(newLongestChain))) {
			res.json({
				note: 'Current chain has not been replaced.',
				chain: bitcoin.chain
			});
		}
		else {
			bitcoin.chain = newLongestChain;
			bitcoin.pendingTransactions = newPendingTransactions;
			res.json({
				note: 'This chain has been replaced.',
				chain: bitcoin.chain
			});
		}
	});
});


// get block by blockHash
app.get('/block/:blockHash', function(req, res) { 
	const blockHash = req.params.blockHash;
	const correctBlock = bitcoin.getBlock(blockHash);
	res.json({
		block: correctBlock
	});
});


// get transaction by transactionId
app.get('/transaction/:transactionId', function(req, res) {
	const transactionId = req.params.transactionId;
	const trasactionData = bitcoin.getTransaction(transactionId);
	res.json({
		transaction: trasactionData.transaction,
		block: trasactionData.block
	});
});


// get address by address
app.get('/address/:address', function(req, res) {
	const address = req.params.address;
	const addressData = bitcoin.getAddressData(address);
	res.json({
		addressData: addressData
	});
});


// block explorer


app.get('/block-explorer', function(req, res) {
	res.sendFile('./block-explorer/index.html', { root: __dirname });
});

app.get('/backtrack',function(req,res){
	const fraud_ini=[88,258,1245,1330,
1693,
1899,
2188,
2324,
2346,
2467,
2555,
2567,
2671,
2696,
2831,
3064,
3117,
3179,
3523,
3545,
4169,
4236,
4284,
4857,
4900,
5011,
5310,
6123,
6210,
6631,
6706,
7178,
8185,
8419,
8679,
9191,
9312,
9453,
9486,
10390,
10511,
10603,
11220,
11400,
11536,
11700,
11969,
12630,
12886,
13277,
13394,
13453,
13454,
13742,
13844,
14116,
14129,
14227,
14327,
14487,
14815,
14966,
15520,
15567,
15631,
16080,
16283,
16293,
16555,
16689,
17031,
17156,
17926,
18713,
18752,
19033,
19058,
19151,
19611,
20496,
20701,
21226,
22131,
22312,
22430,
22590,
23095,
23277,
23397,
23495,
23612,
23760,
23935,
23949,
24125,
24213,
24422,
24524,
24643,
25058,
26333,
26507,
26615,
27182,
28416,
28464,
28582,
28661,
30038,
30389,
30476,
30495,
30518,
30854,
31451,
32017,
32225,
33352,
33451,
33563,
33728,
33864,
34885,
34949,
35080,
35803,
35942,
36092,
36332,
36372,
36421,
36442,
36780,
38333,
38451,
38551,
38797,
38808,
39009,
39366,
39608,
39779,
40014,
40227,
40316,
40524,
40809,
40829,
40865,
41077,
41212,
41455,
41535,
41617,
41642,
42298,
42436,
42809,
43043,
43116,
43656,
43706,
43743,
43840,
43845,
44361,
44676,
44843,
44862,
45203,
45211,
45215,
45217,
45218,45220,45224,45225,45228,45231,45232,45235,45236,45241,45243,45245,45246,45247,45256,45257,45258,45261,45264,45267,45268,45271,45274,45279,45286,45288,45289,45290
];

	// const aadhar=req.body.aadhar;
	// const fatherid=req.body.fatherid;
	// const fatid=req.body.fatid;
	// const requestPromises = [];
	// const requestOptions = {
	// 		uri: 'http://192.168.43.111:8000/for_app',
	// 		method: 'GET',
	// 		json: true
	// 	};
	// 	requestPromises.push(rp(requestOptions));
	// 	Promise.all(requestPromises).then(data=>{
	// 		console.log(`${data}`);
	// 	});
	// 		const fraud=[];
	// const transaction=bitcoin.getAddressData(aadhar).addressTransactions;	
	// var family_trans=[];
	// //var fraud=1;
	// var balance=0;
	// transaction.forEach(tran=>
	// {
	// 	if ((!(tran.sender==fatherid||tran.recipient==fatherid)))
	// 		{
	// 			if(tran.sender==aadhar)
	// 				balance=balance-trans.amount;
	// 			else
	// 				balance=balance+trans.amount;
	// 		}
	// 	else{
	// 			family_trans.push(trans);
			
	// 		}
	// });
	// const requestPromises = [];
	// const requestOptions = {
	// 		uri: 'http://192.168.43.111:8000/for_app',
	// 		method: 'GET',
	// 		json: true
	// 	};
	// 	requestPromises.push(rp(requestOptions));
	// 	Promise.all(requestPromises).then(data=>{
		
	// 	console.log(`${data}`);
		
	// 		res.json({
	// 		data
	// 		});
	// 		});		
	var len=fraud_ini.length;
	const fraud_final=[];
	for(var i=1;i<=4;i++)
	{
		fraud_final.push(fraud_ini[len-i]+"0000000");
		
	}
	fraud_final.push("551731000000");
	for(var i=5;i<=6;i++)
	{
		fraud_final.push(fraud_ini[len-i]+"0000000");
	}
	fraud_final.push("991671000000");
	for(var i=7;i<=10;i++)
	{
		fraud_final.push(fraud_ini[len-i]+"0000000");
	}
	fraud_final.push("789913000000");
	for(var i=11;i<=13;i++)
	{
		fraud_final.push(fraud_ini[len-i]+"0000000");
	}
	fraud_final.push("789913000000");
	for (var i = 14; i <=16; i++) {
		fraud_final.push(fraud_ini[len-i]+"0000000");
	}
	res.json({
		fraud_final
	});
});
	
	//here we have to call model

//});

app.get('/fraud',function(req,res){
	// const requestPromises = [];
	// const requestOptions = {
	// 		uri: 'http://192.168.43.111:8000/for_app',
	// 		method: 'GET',
	// 		json: true
	// 	};
	// 	requestPromises.push(rp(requestOptions));
	// 	Promise.all(requestPromises).then(data=>{
		const fraud12=[551731000000,991671000000,789913000000,789913000000];
		var balance=0;
		var idking=0;
	//	console.log(`${JSON.parse(JSON.stringify(data))}`);
		fraud12.forEach(id=>{
			console.log(`${id}`);
			console.log(`${bitcoin.getAddressData(id).addressBalance}`);
			if (bitcoin.getAddressData(id).addressBalance >= balance)
			{	console.log(`${bitcoin.getAddressData(id).addressBalance}`);
				balance=bitcoin.getAddressData(id).addressBalance;
				idking=0;	
				idking=id;
			}
		});
		var l1=0;
		var l2=0;
		var l3=0;
		var id1=0;
		var id2=0;
		var id3=0;
		var fraudT=[];


		fraud12.forEach(id=>{
			bitcoin.getAddressData(id).addressTransactions.forEach(tran=>{
				if(!fraud12.indexOf(tran.sender==-1)&&(!fraud12.indexOf(tran.recipient)==-1))
				{
					console.log(`${tran}`);
					fraudT.push(tran);
				}
			});
			if(fraudT.length>=l1)
			{
				l1=fraudT.length;
				id1=id;
				console.log(`${id1}`);
			}
		});
		fraudT=[];
		fraud12.forEach(id=>{
			bitcoin.getAddressData(id).addressTransactions.forEach(tran=>{
				if(!fraud12.indexOf(tran.sender==-1)&&(!fraud12.indexOf(tran.recipient)==-1))
				{
					fraudT.push(tran);
				}
			});
			if(fraudT.length<=l1&&fraudT.length>=l2)
			{
				l2=fraudT.length;
				id2=id;
			}
		});

		fraudT=[];
fraud12.forEach(id=>{
			bitcoin.getAddressData(id).addressTransactions.forEach(tran=>{
				if(!fraud12.indexOf(tran.sender==-1)&&(!fraud12.indexOf(tran.recipient)==-1))
				{
					fraudT.push(tran);
				}
			});
			if(fraudT.length<=l2&&fraudT.length>=l3)
			{
				l3=fraudT.length;
				id3=id;
			}
		});
		//console.log(`${data}`);
		res.json({
			"king":{
				"ID":idking,
				"amount":balance
			},
			"b1":{
				"ID":id1,
				"Amount":bitcoin.getAddressData(id1).addressBalance
			},
			"b2":{
				"ID":id2,
				"Amount":bitcoin.getAddressData(id2).addressBalance
			},
			"b3":{
				"ID":id3,
				"Amount":bitcoin.getAddressData(id3).addressBalance
			}
			});
	//		});
			});
	
	//});

app.get('/ml',function(req,res){
	const balance=[];
	const requestPromises=[null];
	const users=[null];
	bitcoin.chain.forEach(block=>{
		block.transactions.forEach(trans=>{
			if(users.indexOf(trans.sender)==-1)
				users.push(trans.sender);
			if(users.indexOf(trans.recipient)==-1)
				users.push(trans.recipient);
		});
	});
	users.forEach(user=>{
		balance.push({
			userid : user,
			balance : (bitcoin.getAddressData(user)).addressBalance
		});
	});
	fs.readFile('csvjson11.json',(err,data)=>{
		if(err) throw err;
		let student = JSON.parse(data);
    	console.log(student);
    	student.forEach(stu=>{
    		balance.forEach(bal=>{
    			if (stu.uid==bal.userid)
    				{	console.log(`stu`);
    					stu.lo_bal=stu.lo_bal+bal.balance;
    					stu.av_bal=stu.av_bal+bal.balance;
    					stu.up_bal=stu.up_bal+bal.balance;
    				}
    			});
    		});
    		var json=JSON.stringify(student);
		fs.writeFile('csvjson11.json',json,'utf8',function(err)	{
			if(err) throw err;
			console.log('complete');
		});
		});
	fs.readFile('csvjson11.json',(err,data)=>{
		if(err) throw err;
		let stud = JSON.parse(data);
		res.json({
			stud
		});
	});
});


app.listen(port, function() {
	console.log(`Listening on port ${port}...`);
});





